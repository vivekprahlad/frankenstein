Frankenstein is a functional testing tool for Java Swing applications

Author: Vivek Prahlad

Documentation
=============

Please refer to the docs directory for the documentation.

Compiling from source
=====================

You will need:

* JDK 1.4 (or above)
* Apache Ant (http://jakarta.apache.org/ant/).

To compile and run tests tests, just type:

    ant

in the trunk directory. This will create a frankenstein.jar file in the 'dist' directory.


More Information
================

Visit http://www.openqa.org/frankenstein for more information.


License
=======

Frankenstein is released under the Apache 2.0 license. Please refer to the LICENCE-2.0.txt file for the details.